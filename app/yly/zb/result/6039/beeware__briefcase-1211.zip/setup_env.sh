cd /testbed/beeware/briefcase
git reset --hard 497011d96416186d4b68b7253f25ab9a5873c9b0
conda activate testbed
python -m pip install --upgrade pip
python -m pip install pytest pytest-json-report toml
python -m pip install .